import java.util.ArrayList; 
import java.util.Collections; 
import java.util.List; 

public class Largest { 

		public static Integer findMax(List<Integer> list) 
	{ 

		
		// create a new list to avoid modification 
		// in the original list 
		List<Integer> sortedlist = new ArrayList<>(list); 

		// sort list in natural order 
		Collections.sort(sortedlist); 

		// last element in the sorted list would be maximum 
		return sortedlist.get(sortedlist.size() - 1); 
	} 

	public static void main(String[] args) 
	{ 

		// create an ArrayList Object list 
		List<Integer> list = new ArrayList<>(); 

		// add element in ArrayList object list 
		list.add(44); 
		list.add(11); 
		list.add(22); 
		list.add(33); 

		
		System.out.println("Max: " + findMax(list)); 
	} 
} 
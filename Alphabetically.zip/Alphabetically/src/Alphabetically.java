import java.util.ArrayList;
import java.util.*;
public class Alphabetically  {

	public static void main(String args[]){
		ArrayList<String> listofnames = new ArrayList<String>();
		listofnames.add("Hasan");
		listofnames.add("Alpha");
		listofnames.add("Stefan");
		listofnames.add("Karim");
		listofnames.add("Poppy");
		listofnames.add("Lalona");
		listofnames.add("isabella");
		listofnames.add("Isabel");
		listofnames.add("Maria");
		listofnames.add("King");
		listofnames.add("Mona");
		listofnames.add("Albert");
		listofnames.add("Pedram");

		System.out.println("Before Sorting:");
		for(String counter: listofnames){
			System.out.println(counter);
		}
		Collections.sort(listofnames);

		System.out.println("After Sorting:");
		for(String counter: listofnames){
			System.out.println(counter);
		}
	}
}